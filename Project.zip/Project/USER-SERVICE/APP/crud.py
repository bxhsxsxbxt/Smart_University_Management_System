from sqlalchemy.orm import Session
from sqlalchemy import select
from APP import models, schemas
from typing import Optional, List


def get_user(db: Session, user_id: int) -> Optional[models.User]:
    stmt = select(models.User).where(models.User.id == user_id)
    return db.execute(stmt).scalars().first()


def get_user_by_email(db: Session, email: str) -> Optional[models.User]:
    stmt = select(models.User).where(models.User.email == email)
    return db.execute(stmt).scalars().first()


def list_users(db: Session, skip: int, limit: int) -> List[models.User]:
    stmt = select(models.User).offset(skip).limit(limit)
    return db.execute(stmt).scalars().all()


def update_user(db: Session, user: models.User, updates: schemas.UserUpdate) -> models.User:
    data = updates.dict(exclude_unset=True)
    for key, value in data.items():
        setattr(user, key, value)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def delete_user(db: Session, user: models.User):
    db.delete(user)
    db.commit()


def upsert_user(db: Session, payload: schemas.UserSync) -> models.User:
    """
    Ensure user profile exists (used for sync from Auth-Service).
    """
    user = db.get(models.User, payload.id)
    if not user:
        user = get_user_by_email(db, payload.email)

    if not user:
        user = models.User(
            id=payload.id,
            email=payload.email,
            full_name=payload.full_name,
            role=payload.role.value if hasattr(payload.role, "value") else payload.role,
            is_active=payload.is_active if payload.is_active is not None else True,
        )
        db.add(user)
    else:
        # ensure IDs stay aligned with Auth-Service
        if user.id != payload.id:
            user.id = payload.id

        updates = payload.model_dump(exclude_none=True)
        # Avoid changing PK
        updates.pop("id", None)
        for key, value in updates.items():
            if hasattr(user, key):
                setattr(user, key, value if not hasattr(value, "value") else value.value)

    db.commit()
    db.refresh(user)
    return user
