from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from APP import models
from APP.database import engine
from APP.ROUTERS import Users
from APP.config import settings

app = FastAPI(title="Users Service")

models.Base.metadata.create_all(bind=engine)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(Users.router)


@app.get("/")
def root():
    return {"service": "users", "status": "ok"}
