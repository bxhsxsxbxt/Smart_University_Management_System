from fastapi import APIRouter, Depends, HTTPException, status, Header
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from APP.database import get_db
from APP import crud, schemas, models
from APP.security import validate_token
from APP.config import settings

router = APIRouter(prefix="/api/users", tags=["users"])

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="NOT_USED_HERE")


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> models.User:
    try:
        token_data = validate_token(token)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = crud.get_user(db, token_data.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    return user


def verify_internal_key(x_service_key: str = Header(None)):
    if x_service_key != settings.INTERNAL_API_KEY:
        raise HTTPException(status_code=403, detail="Forbidden")
    return True


# ------------------------
# Current User
# ------------------------
@router.get("/me", response_model=schemas.UserOut)
def get_me(current_user: models.User = Depends(get_current_user)):
    return current_user


# ------------------------
# List Users (admin only)
# ------------------------
@router.get("/", response_model=list[schemas.UserOut])
def list_users(
    skip: int = 0, limit: int = 100,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    if skip < 0 or limit < 1 or limit > 500:
        raise HTTPException(status_code=400, detail="Invalid pagination")
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin only")

    return crud.list_users(db, skip, limit)


# ------------------------
# Get User By ID
# ------------------------
@router.get("/{user_id}", response_model=schemas.UserOut)
def get_user_by_id(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(404, "User not found")

    if current_user.role != "admin" and user.id != current_user.id:
        raise HTTPException(403, "Not allowed")

    return user


# ------------------------
# Update User
# ------------------------
@router.put("/{user_id}", response_model=schemas.UserOut)
def update_user(
    user_id: int,
    updates: schemas.UserUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(404, "User not found")

    if current_user.role != "admin" and current_user.id != user.id:
        raise HTTPException(403, "Not allowed")

    return crud.update_user(db, user, updates)


# ------------------------
# Delete User
# ------------------------
@router.delete("/{user_id}")
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user)
):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(404, "User not found")

    if current_user.role != "admin" and current_user.id != user.id:
        raise HTTPException(403, "Not allowed")

    crud.delete_user(db, user)
    return {"msg": "Deleted"}


# ------------------------
# Internal Sync (Auth-Service)
# ------------------------
@router.post("/internal/sync", response_model=schemas.UserOut, include_in_schema=False)
def sync_user(
    payload: schemas.UserSync,
    db: Session = Depends(get_db),
    _: bool = Depends(verify_internal_key)
):
    user = crud.upsert_user(db, payload)
    return user
