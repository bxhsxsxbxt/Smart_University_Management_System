from pydantic_settings import BaseSettings
from pydantic import Field, field_validator


class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = Field("postgresql://postgres:postgres@db:5432/users_db", env="DATABASE_URL")

    # JWT config (must be same as Auth-Service)
    SECRET_KEY: str = Field("CHANGE_ME_SECRET", env="SECRET_KEY")
    ALGORITHM: str = Field("HS256", env="ALGORITHM")
    INTERNAL_API_KEY: str = Field("CHANGE_ME_INTERNAL_KEY", env="INTERNAL_API_KEY")

    ALLOWED_ORIGINS: list[str] = Field(default_factory=lambda: ["*"], env="ALLOWED_ORIGINS")

    # Optional
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # Not used in Users-Service

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def split_origins(cls, v):
        if isinstance(v, str):
            return [item.strip() for item in v.split(",") if item.strip()]
        return v

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
