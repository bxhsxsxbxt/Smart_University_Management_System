from pydantic import BaseModel, EmailStr
from typing import Optional
from enum import Enum


class UserRole(str, Enum):
    student = "student"
    teacher = "teacher"
    admin = "admin"


class UserBase(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    role: Optional[str] = UserRole.student
    is_active: Optional[bool] = True


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None


class UserOut(UserBase):
    id: int

    class Config:
        orm_mode = True


class TokenData(BaseModel):
    sub: str   # email
    user_id: int


class UserSync(BaseModel):
    id: int
    email: EmailStr
    full_name: Optional[str] = None
    role: Optional[UserRole] = UserRole.student
    is_active: Optional[bool] = True
