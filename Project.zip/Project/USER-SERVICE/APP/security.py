from jose import jwt, JWTError
from APP.schemas import TokenData
from APP.config import settings

SECRET_KEY = settings.SECRET_KEY
ALGORITHM = settings.ALGORITHM


def validate_token(token: str) -> TokenData:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        sub = payload.get("sub")
        user_id = payload.get("user_id") or payload.get("sub")
        if user_id is None:
            raise JWTError()
        return TokenData(sub=str(sub or user_id), user_id=int(user_id))
    except JWTError:
        raise
