import time
import asyncio
from fastapi import HTTPException


class CircuitBreaker:
    def __init__(self, threshold=3, reset_timeout=10):
        self.threshold = threshold
        self.reset_timeout = reset_timeout
        self.state = "CLOSED"
        self.fail_count = 0
        self.last_fail_time = 0
        self._lock = asyncio.Lock()   # thread-safe

    async def allow(self):
        async with self._lock:
            if self.state == "OPEN":
                if time.time() - self.last_fail_time < self.reset_timeout:
                    raise HTTPException(503, "Service temporarily unavailable (circuit breaker)")
                self.state = "HALF_OPEN"

    async def success(self):
        async with self._lock:
            self.state = "CLOSED"
            self.fail_count = 0

    async def failure(self):
        async with self._lock:
            self.fail_count += 1

            if self.state == "HALF_OPEN":
                self.state = "OPEN"
                self.last_fail_time = time.time()
                self.fail_count = 0
                return

            if self.fail_count >= self.threshold:
                self.state = "OPEN"
                self.last_fail_time = time.time()

circuit_breakers = {
    "auth": CircuitBreaker(),
    "user": CircuitBreaker(),
    "resource": CircuitBreaker(),
    "market": CircuitBreaker(),
    "exam": CircuitBreaker(),
    "iot": CircuitBreaker(),
    "reserve": CircuitBreaker(),
    "shuttle": CircuitBreaker(),
}
