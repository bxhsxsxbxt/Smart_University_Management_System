import redis.asyncio as redis
import json
import os

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")

try:
    redis_client = redis.from_url(
        REDIS_URL,
        decode_responses=True
    )
except Exception:
    redis_client = None


async def get_cache(key: str):
    if redis_client is None:
        return None

    try:
        return await redis_client.get(key)
    except Exception:
        return None


async def set_cache(key: str, data, ttl=10):
    if redis_client is None:
        return

    if isinstance(data, (dict, list)):
        data = json.dumps(data)

    try:
        await redis_client.set(key, data, ex=ttl)
    except Exception:
        pass

async def delete_cache(key: str):
    if redis_client is None:
        return

    try:
        await redis_client.delete(key)
    except Exception:
        pass