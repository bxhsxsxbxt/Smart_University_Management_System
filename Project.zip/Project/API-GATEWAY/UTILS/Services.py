import os

AUTH_SERVICE = os.getenv("AUTH_SERVICE", "http://auth-service:8001")
USER_SERVICE = os.getenv("USER_SERVICE", "http://user-service:8002")
RESOURCE_SERVICE = os.getenv("RESOURCE_SERVICE", "http://resource-service:8003")
MARKET_SERVICE = os.getenv("MARKET_SERVICE", "http://market-service:8004")
EXAM_SERVICE = os.getenv("EXAM_SERVICE", "http://exam-service:8005")
IOT_SERVICE = os.getenv("IOT_SERVICE", "http://iot-service:8006")
RESERVE_SERVICE = os.getenv("RESERVE_SERVICE", "http://reserve-service:8007")
SHUTTLE_SERVICE = os.getenv("SHUTTLE_SERVICE", "http://shuttle-service:8008")


#Mcroservices Adrress