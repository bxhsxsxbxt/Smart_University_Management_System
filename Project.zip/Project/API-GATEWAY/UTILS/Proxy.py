import httpx
import json
from fastapi import Request, HTTPException, Response
from UTILS.CircuitBreaker import circuit_breakers
from UTILS.Cache import get_cache, set_cache

TIMEOUT = 2.0
CACHEABLE_METHODS = ["GET"]


async def forward(request: Request, url: str, service: str, cache_key=None):

    breaker = circuit_breakers[service]

    # 1) Circuit Breaker
    await breaker.allow()

    # 2) Cache (only GET)
    if request.method in CACHEABLE_METHODS and cache_key:
        cached = await get_cache(cache_key)
        if cached:
            try:
                return Response(
                    content=cached,
                    status_code=200,
                    media_type="application/json"
                )
            except:
                return Response(content=cached, status_code=200)

    # 3) Extract Headers
    headers = dict(request.headers)
    headers.pop("host", None)
    headers.pop("content-length", None)

    # 4) Read Body (JSON Safe)
    json_body = None
    raw_body = None

    try:
        json_body = await request.json()
        send_as_json = True
    except:
        raw_body = await request.body()
        send_as_json = False

    try:
        # 5) Send Request
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            if send_as_json:
                resp = await client.request(
                    method=request.method,
                    url=url,
                    headers=headers,
                    json=json_body
                )
            else:
                resp = await client.request(
                    method=request.method,
                    url=url,
                    headers=headers,
                    content=raw_body
                )

        # 6) Circuit Breaker Success
        await breaker.success()

        # 7) Return EXACT response from backend
        # Filter hop-by-hop headers
        excluded_headers = {
            "content-length",
            "transfer-encoding",
            "connection",
            "keep-alive",
            "proxy-authenticate",
            "proxy-authorization",
            "te",
            "trailers",
            "upgrade",
        }
        safe_headers = {
            k: v for k, v in resp.headers.items()
            if k.lower() not in excluded_headers
        }

        # Cache successful GET responses
        if request.method in CACHEABLE_METHODS and cache_key and resp.status_code == 200:
            await set_cache(cache_key, resp.text)

        return Response(
            content=resp.content,
            status_code=resp.status_code,
            headers=safe_headers
        )

    except Exception:
        # 9) Circuit Breaker Failure
        await breaker.failure()
        raise HTTPException(502, f"{service} service unavailable")
