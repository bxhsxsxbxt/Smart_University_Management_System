from fastapi import Request
from fastapi.responses import JSONResponse
from fastapi import HTTPException
from UTILS.Services import AUTH_SERVICE
import httpx

PUBLIC_PATHS = [
    "/api/auth/login",
    "/api/auth/register",
    "/api/auth/refresh"
]

async def verify_jwt(request: Request, call_next):
    path = request.url.path

    if any(path.startswith(p) for p in PUBLIC_PATHS):
        return await call_next(request)

    #  Authorization Header
    token = request.headers.get("Authorization")
    if not token:
        return JSONResponse(status_code=401, content={"detail": "Missing Authorization header"})

    # Delete Docker Problematic Headers
    headers = {"Authorization": token}

    try:
        # Send Verify Request To Auth Service
        async with httpx.AsyncClient(timeout=2.0) as client:
            resp = await client.get(
                f"{AUTH_SERVICE}/auth/verify",
                headers=headers
            )

        if resp.status_code != 200:
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or expired token"}
            )

    except Exception:
        raise HTTPException(503, "Auth service unavailable")

    return await call_next(request)
