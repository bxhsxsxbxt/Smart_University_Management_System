from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from ROUTERS import Auth, Users, Market, Shuttle, Reserve, Exam, IOT
from UTILS.AuthMiddleware import verify_jwt

app = FastAPI(title="University Platform API Gateway")

# -------------------- CORS --------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------- JWT Middleware --------------------
@app.middleware("http")
async def jwt_middleware(request, call_next):
    public_paths = [
        "/api/auth/register",
        "/api/auth/login",
        "/api/auth/refresh",
    ]

    # Public routes → no JWT required
    if request.url.path in public_paths:
        return await call_next(request)

    # Protected routes
    return await verify_jwt(request, call_next)


# -------------------- ROUTERS --------------------
app.include_router(Auth.router, prefix="/api/auth")
app.include_router(Users.router, prefix="/api/users")
app.include_router(Market.router, prefix="/api/market")
app.include_router(Shuttle.router, prefix="/api/shuttle")
app.include_router(Reserve.router, prefix="/api/reserve")
app.include_router(Exam.router, prefix="/api/exam")
app.include_router(IOT.router, prefix="/api/iot")
