from fastapi import FastAPI
from APP.database import engine, Base
from APP.ROUTERS.Auth import router as auth_router
from fastapi.middleware.cors import CORSMiddleware  # IMPORTANT!
from APP.config import settings

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Auth Service")

# Add CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Keep backward compatibility (/auth) and align with frontend expectation (/api/auth)
app.include_router(auth_router, prefix="/auth")
app.include_router(auth_router, prefix="/api/auth")

# Add health endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy"}
