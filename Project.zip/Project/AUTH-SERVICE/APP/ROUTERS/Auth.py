from fastapi import APIRouter, Depends, HTTPException, status, Header
from sqlalchemy.orm import Session
from APP import schemas, crud, security
from APP.database import get_db
from APP.config import settings
from datetime import datetime, timezone, timedelta
from jose import JWTError
import httpx

router = APIRouter(tags=["auth"])  



# -------------------- REGISTER --------------------
@router.post("/register", response_model=schemas.UserOut)
def register(user_in: schemas.UserCreate, db: Session = Depends(get_db)):
    existing = crud.get_user_by_email(db, user_in.email)
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed = security.get_password_hash(user_in.password)
    user = crud.create_user(db, user_in, hashed)

    # Sync user profile into User-Service (keep IDs aligned)
    try:
        resp = httpx.post(
            f"{settings.USER_SERVICE_URL}/api/users/internal/sync",
            json={
                "id": user.id,
                "email": user.email,
                "full_name": user.full_name,
                "role": user.role.value if hasattr(user.role, "value") else user.role,
                "is_active": user.is_active,
            },
            headers={"X-Service-Key": settings.INTERNAL_API_KEY},
            timeout=3.0,
        )
        if resp.status_code >= 400:
            raise HTTPException(
                status_code=502,
                detail="Failed to sync user profile to user-service",
            )
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(
            status_code=502,
            detail="User-Service unavailable during registration",
        )
    return user


# -------------------- LOGIN --------------------
@router.post("/login", response_model=schemas.TokenWithRefresh)
def login(form_data: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = crud.get_user_by_email(db, form_data.email)
    if not user or not security.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    access = security.create_access_token(
        user_id=user.id,
        expires_seconds=settings.ACCESS_TOKEN_EXPIRES_SECONDS
    )

    refresh = security.create_refresh_token(
        user_id=user.id,
        expires_seconds=settings.REFRESH_TOKEN_EXPIRES_SECONDS
    )

    expires_at = datetime.now(timezone.utc) + timedelta(
        seconds=settings.REFRESH_TOKEN_EXPIRES_SECONDS
    )

    crud.create_refresh_token(db, user.id, refresh, expires_at)

    return {
        "access_token": access,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRES_SECONDS,
        "refresh_token": refresh,
        "refresh_expires_in": settings.REFRESH_TOKEN_EXPIRES_SECONDS
    }


# -------------------- REFRESH TOKEN --------------------
@router.post("/refresh", response_model=schemas.Token)
def refresh_token(payload: dict, db: Session = Depends(get_db)):
    token = payload.get("refresh_token")
    if not token:
        raise HTTPException(status_code=400, detail="refresh_token required")

    rt = crud.get_refresh_token(db, token)
    if not rt:
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    if rt.expires_at < datetime.now(timezone.utc):
        crud.revoke_refresh_token(db, token)
        raise HTTPException(status_code=401, detail="Refresh token expired")

    try:
        data = security.decode_token(token)
        user_id = int(data.get("sub"))
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    access = security.create_access_token(
        user_id=user_id,
        expires_seconds=settings.ACCESS_TOKEN_EXPIRES_SECONDS
    )

    return {
        "access_token": access,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRES_SECONDS
    }


# -------------------- LOGOUT --------------------
@router.post("/logout")
def logout(payload: dict, db: Session = Depends(get_db)):
    token = payload.get("refresh_token")
    if not token:
        raise HTTPException(status_code=400, detail="refresh_token required")

    revoked = crud.revoke_refresh_token(db, token)
    if not revoked:
        raise HTTPException(status_code=404, detail="Refresh token not found")

    return {"ok": True}


# -------------------- VERIFY --------------------
@router.get("/verify")
def verify(authorization: str = Header(None)):
    if not authorization:
        raise HTTPException(status_code=401, detail="Authorization header missing")

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header")

    token = authorization.split(" ")[1]

    try:
        payload = security.decode_token(token)
        return {
            "valid": True,
            "sub": payload.get("sub")
        }
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
