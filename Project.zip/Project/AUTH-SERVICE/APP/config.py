from pydantic_settings import BaseSettings
from pydantic import Field
from pydantic import field_validator

class Settings(BaseSettings):
    PROJECT_NAME: str = "Auth Service"
    DATABASE_URL: str = "postgresql://postgres:postgres@auth-db:5432/authdb"
    SECRET_KEY: str = Field("CHANGE_ME_STRONG_SECRET", env="SECRET_KEY")
    ACCESS_TOKEN_EXPIRES_SECONDS: int = 60 * 15
    REFRESH_TOKEN_EXPIRES_SECONDS: int = 60 * 60 * 24 * 7
    ALGORITHM: str = "HS256"
    USER_SERVICE_URL: str = Field("http://user-service:8002", env="USER_SERVICE_URL")
    INTERNAL_API_KEY: str = Field("CHANGE_ME_INTERNAL_KEY", env="INTERNAL_API_KEY")
    ALLOWED_ORIGINS: list[str] = Field(default_factory=lambda: ["*"], env="ALLOWED_ORIGINS")

    @field_validator("ALLOWED_ORIGINS", mode="before")
    @classmethod
    def split_origins(cls, v):
        if isinstance(v, str):
            return [item.strip() for item in v.split(",") if item.strip()]
        return v

    class Config:
        env_file = ".env"

settings = Settings()
