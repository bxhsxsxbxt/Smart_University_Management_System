from datetime import datetime, timedelta, timezone

from jose import jwt, JWTError
from passlib.context import CryptContext

from APP.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def utcnow():
    return datetime.now(timezone.utc)


# ---------------------- TOKEN GENERATION ----------------------
def create_access_token(user_id: int, expires_seconds: int) -> str:
    expire = utcnow() + timedelta(seconds=expires_seconds)

    payload = {
        # Keep sub for backward compat; add user_id for downstream services
        "sub": str(user_id),
        "user_id": user_id,
        "exp": expire,
    }

    encoded_jwt = jwt.encode(
        payload,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )

    return encoded_jwt


def create_refresh_token(user_id: int, expires_seconds: int) -> str:
    expire = utcnow() + timedelta(seconds=expires_seconds)

    payload = {
        "sub": str(user_id),
        "user_id": user_id,
        "exp": expire,
    }

    encoded_jwt = jwt.encode(
        payload,
        settings.SECRET_KEY,   
        algorithm=settings.ALGORITHM,
    )

    return encoded_jwt


# ---------------------- TOKEN DECODE ----------------------
def decode_token(token: str):
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM],
        )
        return payload

    except JWTError as e:
        raise e
