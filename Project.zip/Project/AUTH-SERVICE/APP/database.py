from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from APP.config import settings

# synchronous engine (simple)
engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# dependency for FastAPI
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
